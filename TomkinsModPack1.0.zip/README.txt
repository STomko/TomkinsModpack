Install Forge 28.1.104

Copy the mods into the mods folder.

Enjoy.



For a server, copy the mod files into the server's mod folder.